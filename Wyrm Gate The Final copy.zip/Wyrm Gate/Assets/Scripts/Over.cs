﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;
/*
 * Ryan Kearns
 * 6/16/2016
 */
public class Over : MonoBehaviour {
	// Use this for initialization
	void Start () {
		//GameObject core = GameObject.FindWithTag("Player");
	}
	
	// Update is called once per frame
	void Update () {
		if (GameObject.FindWithTag("Player").activeSelf == true) {

		} else {
			SceneManager.LoadScene ("GameOver");
		}
	}
}
