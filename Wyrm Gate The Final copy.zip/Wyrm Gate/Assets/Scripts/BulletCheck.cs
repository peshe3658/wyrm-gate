﻿using UnityEngine;
using System.Collections;
/*
 * Ryan Kearns
 * 6/16/2016
 * Desc: goes to check script but for the bullets
 */
public class BulletCheck : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		GameController instanceOf = GameObject.Find("GameController").GetComponent<GameController>();
		if (instanceOf.playerCollision(this.gameObject) == true) {
		}
	}
}
