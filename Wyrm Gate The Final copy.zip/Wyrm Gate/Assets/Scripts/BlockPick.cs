﻿using UnityEngine;
using System.Collections;
/*
 * Ryan Kearns
 * 15/06/2016
 * Desc: If the user moves ovr the ghost above build area, the Block is chosen
 */
public class BlockPick : MonoBehaviour {
	public static bool isOn;

	void OnMouseOver(){
		isOn = true;
		CannonPick.isOn = false;
	}
}
