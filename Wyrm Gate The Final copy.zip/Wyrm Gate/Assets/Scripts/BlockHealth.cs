﻿using UnityEngine;
using System.Collections;
/*
 * Ryan Kearns
 * 6/16/2016
 * Desc: This script gives the block health. Other scripts will reference this 
 * when subtracting health, and every frame, the block will check if it has 
 * health If it doesn't, it will be destroyed.
 */
public class BlockHealth : MonoBehaviour {
	public int blockHp;
	// Use this for initialization
	void Start(){
		blockHp = 90;//90 to make block take 3 hits exact
	}
	// Update is called once per frame
	public void takeDamage(){
		blockHp = blockHp - 30;
	}
	void Update () {
		if (blockHp < 1f) {
			Destroy (this.gameObject, 0.0f);
		}
	}
}
