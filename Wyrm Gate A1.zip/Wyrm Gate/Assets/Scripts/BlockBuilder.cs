﻿using UnityEngine;
using System.Collections;

public class BlockBuilder : MonoBehaviour {
    public bool isOn;
	public GameObject Ghost;
	public GameObject Block;
  //  public Renderer rend;
	//public GameObject positions

	// Use this for initialization
	void Start () {
		
//        rend.GetComponent<Renderer>();
       // rend.material.color = new Color(111, 111, 111, 0);
	}

	void FixedUpdate(){
		if (Input.GetButtonDown("Fire1") && Highlight.over == true) {
			//check if spot has object
			//Quaternion rotation = new Quaternion (0, 0, 0, 0);
			Instantiate(Block, Highlight.positions, Quaternion.identity);
			//make blocks children of core


		}
	}
	// Update is called once per frame
		//when mouse over highlighted sprite
		//on mouse click
		//checks coords and places in variables
		//checks if object at coords
		//if not, instantiate
		
}
