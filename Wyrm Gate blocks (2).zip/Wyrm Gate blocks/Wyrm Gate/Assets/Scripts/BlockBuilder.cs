﻿using UnityEngine;
using System.Collections;

public class BlockBuilder : MonoBehaviour {
    public bool isOn;
    public Renderer rend;
	public GameObject block;
	public int length = 0;
	// Use this for initialization
	void Start () {
		block.GetComponent<Transform> ();
        rend.GetComponent<Renderer>();
		block.GetComponent<Collider2D> ();
        rend.material.color = new Color(111, 111, 111, 0);
	}
	
	// Update is called once per frame
	void IsNext(){
		Vector3 center = new Vector3(block.transform.position.x,block.transform.position.y+1, block.transform.position.z);
		Vector3 size = new Vector3 (0.5f, 0.5f, 0.5f);
		Quaternion rotation = new Quaternion (0.0f, 0.0f, 0.0f, 0.0f);
		//ArrayList colliders = new ArrayList;
		Collider[] colliders = Physics.OverlapBox (center, size, rotation, 0, QueryTriggerInteraction.Collide);
		if(colliders.Length < 1){
			length = 0;
		}
		else{
			length = 1;
			}
	}

	void OnMouseOver () {
		IsNext();

		if (length < 1) {
		}
		else{
			rend.material.color = Color.gray;

			if (Input.GetMouseButtonDown (0) == true && length == 1) {
				isOn = true;
			}
			if (Input.GetMouseButtonDown (1) == true && length == 0) {
				isOn = false;
			}
		}

    }
    void OnMouseExit() {
        rend.material.color = new Color(111, 111, 111, 0);

    }
    void Update() {
        if(isOn) {
            rend.material.color = Color.grey;
        }
    }
}
