﻿using UnityEngine;
using System.Collections;
/*
 * Ryan Kearns
 * 10/06/2016
 * Desc: Script for the building scene. This script allows the player to place and remove blocks
 */
public class BlockBuilder : MonoBehaviour {
    public bool isOn;
	public GameObject Ghost;
	public GameObject Block;
	public GameObject Core;
	public GameObject[] placeArray;
	private int index;
  //  public Renderer rend;
	//public GameObject positions

	// Use this for initialization
	void Start () {
		index = 0;
		placeArray = new GameObject[48];
//        rend.GetComponent<Renderer>();
       // rend.material.color = new Color(111, 111, 111, 0);
	}

	void FixedUpdate(){
		if (Input.GetButtonDown("Fire1") && Highlight.over == true) {
			//check if spot has block object
			//for loop finds if any block at highlight position retruns true if any are
			if (Highlight.positions == Block.transform.position || Highlight.positions == Core.transform.position) {

			} else {
				GameObject blockClone = (GameObject) Instantiate (Block, Highlight.positions, Quaternion.identity);

				//GameObject BlockClone = Block.
				//make blocks children of core
				blockClone.transform.SetParent( Core.transform);
				//adds block to object array
				placeArray[index] = blockClone;
				index ++;

			}


		}
		//player removing blocks
		if (Input.GetButtonDown ("Fire2") && Highlight.over == true) {
			//checks if spot has a block to remove

		}
	}
	// Update is called once per frame
		//when mouse over highlighted sprite
		//on mouse click
		//checks coords and places in variables
		//checks if object at coords
		//if not, instantiate
		
}
