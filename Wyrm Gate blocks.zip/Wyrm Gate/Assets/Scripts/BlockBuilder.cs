﻿using UnityEngine;
using System.Collections;

public class BlockBuilder : MonoBehaviour {
    public bool isOn;
    public Renderer rend;
	// Use this for initialization
	void Start () {
        rend.GetComponent<Renderer>();
        rend.material.color = new Color(111, 111, 111, 0);
	}
	
	// Update is called once per frame
	void OnMouseOver () {
        rend.material.color = Color.gray;
        if(Input.GetMouseButtonDown(0)== true /*&& block next to other block*/) {
            isOn = true;
        }
        if (Input.GetMouseButtonDown(1) == true) {
            isOn = false;
        }

    }
    void OnMouseExit() {
        rend.material.color = new Color(111, 111, 111, 0);

    }
    void Update() {
        if(isOn) {
            rend.material.color = Color.grey;
        }
    }
}
