﻿using UnityEngine;
using System.Collections;

public class Highlight : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	//area is null colour
	//when user over area, blocks drawn in placeable areas
	//draws and destroys when mouse position over area
	//converts mouse floats to integers
	//if area placeable sends true to blockBuilder
}
